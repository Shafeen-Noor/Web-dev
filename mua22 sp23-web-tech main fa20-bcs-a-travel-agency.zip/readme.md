# Travel Agency App 

Coded for my awesome class of FA20-BCS-A 

Run following command to install dependices 

> npm install 

run the app as 

>node server

or use nodemon 

install nodemon once globally 

>npm i -g nodemon

then start as 

nodemon server

